const express = require('express')
const upload = require('express-fileupload')

const app = express()

app.use(upload())
app.get('/',(req, res) => {
    res.sendFile(__dirname +'/login.html')
})
app.post('/uploads', (req, res) =>{
    res.sendFile(__dirname +'/fileindex.html')
})

app.post('/save', function (req, res) {
    let sampleFile;
    let uploadPath;

    if (!req.files || Object.keys(req.files).length === 0) {
        return res.status(400).send('No files were uploaded.');
    }

    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    sampleFile = req.files.file;
    uploadPath = __dirname + '/uploads/' + sampleFile.name;

    // Use the mv() method to place the file somewhere on your server
    sampleFile.mv(uploadPath, function (err) {
        if (err)
            return res.status(500).send(err);

        res.send('File uploaded! \n your 6 digit code is generated :'+Math.round(Math.random()*1000000));


    });
});
app.listen(5000)

// you can see login page on localhost:5000